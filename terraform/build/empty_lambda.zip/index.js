// this is an empty lambda
// we expect it to fail all invocations
